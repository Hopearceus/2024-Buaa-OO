import java.util.ArrayList;

public interface Factor {
    ArrayList<Term> getTerms();
}
