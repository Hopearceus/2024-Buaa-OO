public interface Function {
    boolean hasFunc(String str);

    String replaceFunc(String str);
}
